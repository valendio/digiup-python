from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import Makanan
from .models import Catering
# Register your models here.
admin.site.register(Makanan)
admin.site.register(Catering)

# Register your models here.
