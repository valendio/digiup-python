nilai = 80
if(nilai > 70):
    print("Lulus")
elif(nilai > 60):
    print("KKM")
else:
    print("bye bye")