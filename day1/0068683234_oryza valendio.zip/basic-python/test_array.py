from array import array
myarray = array('i',[1, 2, 3, 4, 5])
print(myarray)