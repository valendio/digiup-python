new_dict = {
"brand": "Honda",
"model": "Civic",
"year": 1995
}
print(new_dict)
new_dict["year"] = 2000
print(new_dict)
#menampilkan berdasarkan key
print(new_dict["brand"])

