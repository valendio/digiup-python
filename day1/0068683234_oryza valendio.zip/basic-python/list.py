my_list = list([1,2,3,4])
my_list.append(5)
print(my_list)