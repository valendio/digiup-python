import function2

y = function2.tambah(3, 4)
print(y)