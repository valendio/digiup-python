nama = "oryza valendio"
print("upper : ", nama.upper())
print("Capitalize : ", nama.capitalize())
print("Tittle : ", nama.capitalize())

value = "100"
print("isdigit", value.isdigit())
print("isalpha", "123".isalpha())