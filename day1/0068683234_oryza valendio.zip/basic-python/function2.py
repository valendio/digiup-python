def tampil():
    print("Isi function tampil")

# tampil()

def tambah(a, b):
    c = a+b
    return c
z = tambah(1, 4)
print(z)
