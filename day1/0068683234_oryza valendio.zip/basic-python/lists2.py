my_list = [1, 3, 4,2]
my_list.append(5)
print(my_list)
my_list.reverse()
print(my_list)
my_list.sort()
print(my_list)
my_list.sort(reverse=True)
print(my_list)
#combine lists
my_list2 = ["a", "b", "c"]
combo_list = my_list + my_list2
print(combo_list)
combo_list.sort()