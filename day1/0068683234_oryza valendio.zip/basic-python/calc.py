"""add x,y."""
def add(x, y):
    return (x+y)
"""subtract x,y."""
def subtract(x, y):
    return (x-y)
