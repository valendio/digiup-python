name = input("Input your name :")
print(name)