name = "Oryza Valendio";
print(name);

